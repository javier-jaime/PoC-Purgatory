================================
Dave Walley <davewalley54@gmail.com>
Javier:
Is the priority to (1) fix the spreadsheet, or (2) get something on the web to show frequent updates, or (3) something else?

Is a spreadsheet the way to go, or, was Excel used because that was easiest at the time and another kind of interface would be better?

Is the spreadsheet available to us to examine, or is it simpler/better to start from scratch?

Mix Telematics says on their website that they are "App-centric". In my world, this is a terrible thing - data-centric is what you want to be.

Dave

priority 1 is the mission impossible due tonight where Mark BM delivered a half-baked solution to add a journey management plan for the POM case.

No need to fix the spreadsheet for the simberi mine, I can do that but they will no pay for it, excel is being used for the lack of functionality of the MiX Telematics system. 
I do have the spreadsheet with the highlighted errors.

MiX Telematics is a BI Tool from the late 90's, is designed to export to excel, I know all the glitches and I have done the EDA for datasets from all their sites, I have the jupyter notebooks.

We can talk later, I will involve you in the plan B, and we need to do something useful for all our clients not just the SA big boss (Harold).

============================

Javier Jaime

Check this, it is a good starting point for a real time logistics tracking app.
This is a plan B, but doesn't connect to MiX Telematics API, but we can work with any cloud pubsub, apache kafka is the standard.
https://github.com/neo4j-examples/supply-chain-demo
https://practical-meitner-5e75ca.netlify.app/exercises/593b9e22-fa84-48f9-825d-811e1b43a05b/setup

=============================

From: Bruce Gilkes <bgilkes@altscanada.com>
To: Mark Boulton-Mills <mark@methodexists.com>
Cc: Mark Deller <mdeller@altscanada.com>

I have a plan for the demo.  I am using this scenario: https://practical-meitner-5e75ca.netlify.app/exercises/5e1d0d87-d9a1-43c4-b8f4-7dc5959c90dd/setup

THE INTENT OF THE DEMO - is to show the planning capabilities, by building a Journey Management Plan as well as (via Javier) Showing the monitoring of “real-time” telematics against the plan.

Because we haven’t been able to get the Mix API to work yet (security issue), and because we haven’t actually planned journeys against which they will execute today, we need to find another way to demonstrate. 

So the plan is to  “reverse engineer” a plan for “yesterday" (with some deliberate missed timings) using "today’s data" from Mix Telematics.  I have done all the prep work to make this possible:

I have downloaded the Mix telematics data from EFM for 6 October, trimmed the data set to just include the sites (with Lat/Long) that were visited during the half-day’s trips on 6 Oct.  This is attached below ("EFM Sites 7 Oct.CSV") just FYI 
imported the above CSV and created a table in ARTEMIS called "EFM Sites (Import 7 Oct 22)” - again, just FYI
Imported the Table to build the entities for the sites (NOTE:  there is currently no way to enable storage or any of the other newer capabilities at the import stage - it all has to be “hand bombed” after import - again, just FYI for now, but a major pain
Took the Mix Data for the half day’s trips for 6 Oct and cut out all the zero and near-zero length trips to simplify the data.  This is attached below as "Demo Mix Report to MST (EFM) 7 Oct 22”, again FYI
Took the "Demo Mix Report to MST (EFM) 7 Oct 22" data and started creating the journey management plan in EFM Logistics in the above scenario by using the “actuals” from the Mix Data (with some missed timings deliberately introduced)

CRITICAL PROBLEM:  The Logistics EFM entries are not saving - Only the first order saves.  NEED FIXED ASAP, as it is a “dead end" for me and I can’t do any more

Also as discussed the following will have to be done ASAP, in order for Javier to do any comparative analysis of the “actual”  timings against the “plan":

Need to add a start time (default 09:00, editable) and have the delays added and when you select the same vehicle for another mission it puts that mission start time as the previous mission end time (editable so you can give the guy an hour for lunch, etc.)
Need to add a print by vehicle function/button that will allow you to print all order, by vehicle, then chronologically, including start/end times.
Also need to be able to use the same function to export a .csv. as Javier will import/use this for the comparison calculations

With these problems fixed and/or functionality added, I will be able to finish building out the demo Journey Management Plan and then export the plan as a .CSV.  Javier will then hopefully be able to compare this to the “actuals” in the spreadsheet below and trigger any warnings for and (deliberately inserted) missed timings.  

Again, this is essentially backwards, but necessary in order to have a successful demo.

Let me know any feedback you might have ASAP.

Thanks!

LCol (ret’d) Bruce Gilkes
>>>>>>>>>>>>>>>>> 2 Attachments
===========================
Javier Jaime
Fri, Oct 7, 9:03 AM (6 days ago)
to me

FYI
>>>>>>>>>>>>>>>>>>>>>>> ?
---------- Forwarded message ---------
From: Bruce Gilkes <bgilkes@altscanada.com>
Date: Thu, Oct 6, 2022 at 10:37 PM
Subject: EFM/MST (Papua New Guinea) Process and Requirements - Need an estimate
To: Mark Deller <mdeller@altscanada.com>, Mark Boulton-Mills <mark@methodexists.com>, Javier Jaime <jjaime@altscanada.com>

All,
The demo went well and we are back on track with the customer…We are quite close
The following are the overall requirements from Harold and his discussions with EFM.  Some of these requirements we meet right now, some we partially meet, and some would need development. 

TASK:  Estimate the time to do these requirements.  After we have a days/hours estimate we will then prioritize what gets done (working with Harold).  
GOAL:  Minimum Viable Product with Maximum interaction with the Customer
RESTRICTIONS:  
Customer wants and needs the system, but is a bit skittish - they have been burned before
Not sure how much money they have for Dev so we want to absolutely minimize the work on our part wherever possible, until we are under paid contract with the end customer
Need to plan and develop without creating one-offs or single customer “throwaways" 

Mark B, please let me know when you can have an estimate on the modifications to the simulation (import orders, reports, adding Gantt view)
Javier, Mark B, Mark D - Let me know when we can have a discussion around the Real Time monitoring and how it might work/be integrated/be bolted on

Note:  We will always be connecting to different systems for planning and for monitoring so let’s think about this from connecting to multiple different systems in the design and not “just” connecting with Mix Telematics.  The simulation is mainly used for planning. I believe there is also a “bolt on” dashboard and real-time monitor needed that works/integrated with but is separate from the workings of the Simulation.  Also, the systems that we connect to will also have dashboards, real-time monitoring, maps, etc. that we shouldn’t duplicate unless necessary.

All of these points are from Harold and from his discussions with Express Freight Management.  I believe these requirements are not unique to EFM and could be useful by other logistics/transportation companies.

(Note: some of these are repetitive - no need to double estimate)
PROCESS 
1.      3 PM each day the loads for the fleet will be uploaded to each vehicle in the fleet with each complete journey <— Done. Process is currently manual, so we should plan on an eventual import of a .csv from another system 
2.      Each journey will flow to the next ie start at the drop position from the previous load.  <— Does it autofill the next journey start time from the previous journey end time or does it default to 8:00?
3.      Load types will be developed and requested by SR to Mix <— Done.  Products does this.  I believe they are not thinking about the actual goods shipped, but rather whether it is a box, pallet, container, etc.
4.      With all loads accepted to system will commence tracking each load from the start of the flowing days shift <— This is a separate “bolt on” monitoring/alert system that we would have to create and integrate…BUT I think the simulation should mainly stick with Planning — NEED A LOT MORE DISCUSSION AROUND THIS BEFORE IT CAN BE ESTIMATED
5.      The loads will show in real time on mix fleet manager is some way <—Harold is thinking that the best way to show the progress is via a Gantt chart, but rather than a staggered waterfall with each timing for an order, it would have different colours for load time, drive time, unload time, delay time so it all shows on one line in the Gantt (kind of like how hard drive usage is shown in system settings)
PastedGraphic-1.png
6.      Streams will be reflecting delays from each planned journey in real time as they occur <— Harold is thinking of inferring the information from Mix somehow and showing the “actual” delay somehow in our “planned" Gantt chart - see below
7.      There will be a report at Midday on the progress of the whole fleets JMPs <— this would be auto-generated at Time X on Days Y and saved/exported/emailed
8.      There will be a report at the end of the day on the same <— as above, this would be auto-generated at Time X on Days Y and saved/exported/emailed
9.      Any other reports <— Need to add sort to all columns when clicked on, and probably a filter to include/exclude columns in any report.  Need a simple report manager to set this up and manage the auto generation and save/export/email of the reports
10.     Carry overloads not completed to the next day <— This is done already. You just click on the Order, Edit and then change the day to Tomorrow. 

OTHER REQUIREMENTS
1.      Simulation of a days loads on a selected fleet <— Part 1 - Show the Gantt diagram for tomorrow’s deliveries. Listed by truck then order.  Part 2 - show visually in the simulation (generate routes, drive the routes according to the plan for users to visualize spatial relationships between orders, vehicles, locations
2.      Understanding of the real time tracking and streaming related to the JMP <— As per above, this is likely showing the Gantt chart for the orders, and having a line for “Now” with a marker on each Gantt row showing where the “actual” is.  Orders that haven’t started should be greyed out...
3.      How best to track the status of the JMP <— as per above
Below is additional requirements that I think I can manage as they are “non developmental” or ancillary to the development:
4.      A full SOP as follows: <— Harold means “Documentation, Training and Process”
        a.      Requirements into the system to fully run the JMP <— what are the start conditions
        b.      Requirements from MIX
        c.      Requirements from EFM
        d.      Step by step creation of the loads in the workflow
        e.      Reports on the loaded JMP’s for management approval before the shift
        f.      How to monitor the journeys
        g.      How to reallocate Journeys during the shift if trucks break down
        h.      How to add late JMPs when required
Thanks!
LCol (ret’d) Bruce Gilkes
====================
Dave Walley <davewalley54@gmail.com>
Fri, Oct 7, 12:22 PM (6 days ago)
to Javier
I am available again if you want to continue the conversation,
Dave
=============================
Bruce Gilkes <bgilkes@altscanada.com>
11:36 AM (44 minutes ago)
to Harold, Phillip, andy, Javier, Mark
Last night I spoke with the dev team that will be working on the project and here is the plan to get this working as intended:
- Start work immediately on building out the comparison tool that we currently have into a web application for monitoring.  
- We won’t use ARTEMIS for this as it is more suitable for planning and simulating different options than monitoring.  
- ARTEMIS can be reintroduced later one we get to prediction and better planning, etc.

Here is the work we are contemplating:
1.  Web form to upload the .JMP file for processing
        - User will be able to download a .pdf file of the JMP split into individual driver/vehicle Trip Sheets
        - Printing the .pdf will yield the paper sheets to hand out to the drivers plus a paper overview of all trips that day (reprint of the whole JMP)

2.  Comparison will be performed automatically (when the day ends) and the results (.xls comparison) 
        - will be placed in an online location (Like Google Drive) 
        - available for download at any time (after processing)

3.  We will be creating a separate monitoring web application that will perform similarly to the Mix Journey Management (without the onerous preparation)
        - User will upload tomorrow’s JMP as per above
        - Monitoring app will automatically communicate with Mix and track progress in real-time for vehicles being managed in the JMP
        - JMP will then appear in the monitoring web app, along with any previous JMPs and results
                - coloured bars showing loading/unloading/Travel time and load number
                - separately coloured bars showing actual progress against the JMP
                - Red is severely delayed (>30 min), orange is delayed (10-30 min), green is on time (<10min)
                - Warnings will be given: 
                        - for vehicles that are delayed. Initially will just pop up as a notification within the Web App, but may expand later (i.e. SMS)
                        - Later we will build out recommendations to redistribute any late/impossible loads to other vehicles
                        - Warnings will also be given if JMP is “impossible” (i.e. truck is scheduled to deliver Load 1 until 10am, but Load 2 is scheduled to start delivery at 9:30)
                                - User can hand modify elements of the JMP (change start time, travel time, load/unload time, etc.) and will be given an “are you sure?” warning

I should find out today what the ETA for this work will be.  In the meantime, the comparisons will continue to be delivered daily.
The rest of the functionality would be in the second phase

4.  Dashboard Web Application 
        - shows daily/weekly summary in a dashboard (as a web site) that can be added as a component to other dashboards or viewed directly
        - will show progress of JMP for the various EFM business areas in summary (how many loads on time, how many delayed, etc.)
        - this is what is currently being shown on the first page of the .xls that Howard produces
5.  Improvements
        - We would track travel times via Mix for various times of the day/days of the week and create a database
                - This database would recommend the most suitable travel time (user can override) when building a JMP
        - Can recommend the closest suitable vehicle for an unscheduled pickup/delivery
        - Can display current locations on a map (with a better user interface than Mix)

Bruce
==============
Bruce Gilkes <bgilkes@altscanada.com>
Attachments >>>>>>>>>>>>>>>>>>>>>>>>>>>>> PastedGraphic-7.png PastedGraphic-2.tiff PastedGraphic-3.tiff PastedGraphic-4.tiff PastedGraphic-5.tiff
Mon, Dec 5, 2:45 PM (3 days ago)
to Javier, me
Dave,
For background for our discussion in a couple hours...
 I think we are going to have to move ahead with developing a separate module.  What they are asking for (monitoring, comparison) has little to do with simulation so I don’t see the sense in doing it there.  Eventually we would want to seamlessly exchange data without export/import between ARTEMIS and this module, but I’m not wasting a month and a half doing anything now.
I have enclosed a block diagram, below.  I think what we have to do is the green portion as soon as possible. The stuff in blue are the next steps.  After this we will be adding in a bunch of analytics
Javier, can you please have a look at this?  The Monitor JMP Web App would have to be a timeline that functions pretty much as per the screen shots from Mix, below.  There would also be an “Import JMP” button on the bottom.  The timeline would show any imported JMPs and any activities against the JMP.  We would assume as we do now, that the first time a truck arrives at a JMP destination it fulfills the first planned trip, and not one that may be a closer match in time.
We will still have to produce the JMP DRM comparison on a daily basis, but would need to do the real-time monitoring ongoing
There will also have to be Settings module (not shown) where we would have the Mix Settings, Select which trucks to plan/manage/monitor, etc.
Let me know your thoughts!  All the best,
Bruce
===========================
Javier Jaime
Attachments >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> EFM_POM_-_GFI_JMP_-_06_12_2022.xlsx GFI_JMP_data_comparison_06_12_2022.xlsx
Tue, Dec 6, 12:44 PM (2 days ago)
to me

FYI
---------- Forwarded message ---------
From: Javier Jaime <jjaime@altscanada.com>
Date: Tue, Dec 6, 2022 at 7:03 AM
Subject: EFM Automated JMP vs DMR December 6th
To: Bruce Gilkes <bgilkes@altscanada.com>, Harold Richardson <harold@mastersystems.com.pg>, <andy@mastersystems.com.pg>, Howard Numan <howard@mastersystems.com.pg>, <phil@mastersystems.com.pg>
Please see attached automated comparison of EFM GFI JMP vs DMR for December 6th.
Please let me know if you have any comments,
Best Regards,
Javier Jaime
===============================
Javier Jaime
Attachments >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Daily Movement Report.csv
Tue, Dec 6, 12:45 PM (2 days ago)
to me
---------- Forwarded message ---------
From: <no_reply@mixtelematics.com>
Date: Tue, Dec 6, 2022 at 7:00 AM
Subject: EFM-GFI_DRM
To: <mark@methodexists.com>, <jjaime@altscanada.com>, <bgilkes@altscanada.com>
+------------------------------------------+
| Insight report subscription              |
| Good day                                 |
| Organisation name : Express Freight      |
| Report on type : Asset                   |
| Subscription name : EFM_GFI_DMR          |
| Subscription owner : Bruce Gilkes        |
| Frequency of report subscription : Daily |
| Chosen date range : Yesterday            |
| Regards                                  |
| The MiX Telematics Team                  |
+------------------------------------------+
MIX TELEMATICS
=========================================
Bruce Gilkes
Tue, Dec 6, 1:14 PM (1 day ago)
to Harold, Phillip, andy, Mark
For timing and Phase close out clarification:
Phase 1 - (Items 1 & 2, below) will be closed out around the end of this week and this will close out our Phase 1 work for you, Harold.
Phase 2 - (Item 3) will be done around the end of the month and subject to whatever agreement Phil and Mark work out.  There are approximately 3 weeks of work total with both Phase 1 and 2
Phase 3 - (Items 4 & 5, below) will follow on after Christmas.  As per Phase 2, this will be subject to the same agreement with Phil/Mark on development and revenue/sales.
This means that, shortly, Howard will be able to upload the JMP file and it will be processed into a .pdf that will have the full plan on page 1, and the individual driver/vehicle trip plans on subsequent pages.  This will be available for download at a particular web address/site.  When the next day is over, an additional file will be placed in the same location that will have the Daily Movement Report comparison.  
Around Christmas or before the start of the new year, we will have a separate web app for monitoring where you will be able to see what is going on/alarms for late shipments.
After Christmas we would be working on the optimization and dashboard.
Bruce
==================
Bruce Gilkes
Attachments        >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Run Sheet Sample.xlsx
9:06 AM (12 hours ago)
to me, Javier
This is an example of the trip sheets needed. Can be .pdf or .xls as desired 
LCol (ret’d) Bruce Gilkes
- - - - - - - - - - - - - - - -
From: harold@mastersystems.com.pg
Date: December 6, 2022 at 11:40:54 PM MST
To: Bruce Gilkes <bgilkes@altscanada.com>
Subject: FW: Run Example
Hi Bruce
Did you get this.  Please advise, what is the status of this being available off the system?
- - - - - - - - - - - - - - - - - - - - -
From: Howard Numan <howard@mastersystems.com.pg>
Sent: Monday, 5 December 2022 10:50 AM
To: 'Bruce Gilkes' <bgilkes@altscanada.com>; 'Javier Jaime' <jjaime@altscanada.com>; andy@mastersystems.com.pg
Cc: 'Harold Richardson' <Harold@mastersystems.com.pg>; 'Christiegayle Masen' <christiegayle@mastersystems.com.pg>; 'Jirehbless Suve' <jirehbless@mastersystems.com.pg>
Subject: Run Example
Hi All,
Please find a example copy of the run sheets to be printed for EFM JMP Drivers.
The sheet prints out data from workflow template and has spaces for drivers to note down their actuals as well.
Howard Numan    howard@mastersystems.com.pg | Digicel: +67571246556
================================================================
Javier Jaime
EFM Automated JMP vs DMR December 8th
Attachments >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>     EFM_POM_-_GFI_JMP_-_08_12_2022.xlsx GFI_JMP_data_comparison_08_12_2022.xlsx
8:08 AM (6 hours ago)
to Bruce, Harold, andy, Howard, phil, me
Please see attached automated comparison of EFM GFI JMP vs DMR for December 8th.
Please let me know if you have any comments,
Best Regards,
Javier Jaime
=============================================
Javier Jaime
Fwd: EFM POM PFL - Workflows 07.12.2022
Attachments >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>     EFM POM - GFI JMP Workflow 07.12.2022.xlsx 
                                                                        EFM POM JMP Template.xlsx
11:06 AM (3 hours ago)
to me
Attached is the original template.
---------- Forwarded message ---------
From: Bruce Gilkes <bgilkes@altscanada.com>
Date: Tue, Dec 6, 2022 at 5:18 PM
Subject: Fwd: EFM POM PFL - Workflows 07.12.2022
To: Javier Jaime <jjaime@altscanada.com>
Not sure if this is what you need or not…
LCol (ret’d) Bruce Gilkes
- - - - - - - - - - - - - - - - 
From: "Howard Numan" <howard@mastersystems.com.pg>
Subject: RE: EFM POM PFL - Workflows 07.12.2022
Date: December 6, 2022 at 4:53:30 PM MST
To: "'Gamu Raymond'" <adminpfl@expressfreight.com.pg>, "'Benjamin Marais'" <ben.marais@expressfreight.com.pg>
Cc: "'Christiegayle Masen'" <christiegayle@mastersystems.com.pg>, "'Harold Richardson'" <Harold@mastersystems.com.pg>, "'Jirehbless Suve'" <jirehbless@mastersystems.com.pg>, "'Allan Okoa'" <allan@mastersystems.com.pg>, "'Carl Vermaas'" <carl@expressfreight.com.pg>, "'Bruce Gilkes'" <bgilkes@altscanada.com>
Hi Gamu,
As per our call, please find attached a copy of GFI’s workflow for reference and the new template which includes driver Armstong Basua.
Each trip to be filled in each line.
Empty/Return trips will not have loads filled in,
Please advise should you have any queries.
Kind Regards,
Howard Numan
- - - - - - - - - - - - - - - - 
From: Howard Numan <howard@mastersystems.com.pg> 
Sent: Wednesday, 7 December 2022 9:22 am
To: 'Gamu Raymond' <adminpfl@expressfreight.com.pg>; 'Benjamin Marais' <ben.marais@expressfreight.com.pg>
Cc: 'Christiegayle Masen' <christiegayle@mastersystems.com.pg>; 'Harold Richardson' <Harold@mastersystems.com.pg>; 'Jirehbless Suve' <jirehbless@mastersystems.com.pg>; 'Allan Okoa' <allan@mastersystems.com.pg>; 'Carl Vermaas' <carl@expressfreight.com.pg>; 'Bruce Gilkes' <bgilkes@altscanada.com>
Subject: RE: EFM POM PFL - Workflows 07.12.2022
Hi Gamu,
Ill give you a call around 9:30 AM and we will go through the Workflows again to smooth out the departure/arrival times.
Kind Regards,
Howard Numan
- - - - - - - - - - - - - - - - - - - - - - - - - 
From: Gamu Raymond <adminpfl@expressfreight.com.pg> 
Sent: Wednesday, 7 December 2022 9:06 am
To: Howard Numan <howard@mastersystems.com.pg>; Benjamin Marais <ben.marais@expressfreight.com.pg>
Cc: 'Christiegayle Masen' <christiegayle@mastersystems.com.pg>; 'Harold Richardson' <Harold@mastersystems.com.pg>; 'Jirehbless Suve' <jirehbless@mastersystems.com.pg>; 'Allan Okoa' <allan@mastersystems.com.pg>; Carl Vermaas <carl@expressfreight.com.pg>; 'Bruce Gilkes' <bgilkes@altscanada.com>
Subject: RE: EFM POM PFL - Workflows 07.12.2022
Good morning Howard,
Apologies for the delay, find attached PFL JMP report copies from date 05 & 06/12/2022. 
Regards,
Gamu Raymond | PFL  Admin Controller – Port Moresby
PO Box 137  Port Moresby, NCD | Konebada, Papa Lealea Rd, Central Province
Email: adminpfl@expressfreight.com.pg
Tel: 3005500 /Ext: 2049
Mobile: 7385 0452
Website: www.expressfreight.com
Branches at: Lae | Port Moresby | Brisbane | Honiara|Nadi
- - - - - - - - - - - - - - - - - 
From: Howard Numan [mailto:howard@mastersystems.com.pg] 
Sent: Wednesday, 7 December 2022 8:43 AM
To: Gamu Raymond <adminpfl@expressfreight.com.pg>; Benjamin Marais <ben.marais@expressfreight.com.pg>
Cc: 'Christiegayle Masen' <christiegayle@mastersystems.com.pg>; 'Harold Richardson' <Harold@mastersystems.com.pg>; 'Jirehbless Suve' <jirehbless@mastersystems.com.pg>; 'Allan Okoa' <allan@mastersystems.com.pg>; Carl Vermaas <carl@expressfreight.com.pg>; 'Bruce Gilkes' <bgilkes@altscanada.com>
Subject: EFM POM PFL - Workflows 07.12.2022
Good Morning Ben and Gamu,
Please send through PFL workflow that you have for today and we will upload them.
Kind Regards,
Howard Numan
Email: howard@mastersystems.com.pg | Digicel: +67571246556
=====================================================

Conversation opened. 2 messages. All messages read.

Skip to content
Using Gmail with screen readers
4 of 3,638
POM EDA Python Script
Inbox

Javier Jaime
Attachments11:03 AM (3 hours ago)
I was able to run the attached script from git bash (unix shell), but I still need to download and rename the input files. If I can get them in a cloud/drive st

Bruce Gilkes
11:06 AM (3 hours ago)
to Javier, me

I think it looks good.  The thing they are looking for ASAP (like tomorrow if you could do so) is:
- Upload Form to load the JMP into a location for processing (or instructions on where to put it, while that form is being built)
- Automatically create Trip Sheets (individual vehicle trips from JMP) and dump them somewhere they can access and print out on paper
- Automatically compare the JMP against the DMR at the end of tomorrow and dump the comparison somewhere they can access.

Thanks!
Bruce
================================================
Bruce Gilkes
11:18 AM (3 hours ago)
to Javier, me

FYI see comments from Harold, below in RED
LCol (ret’d) Bruce Gilkes
https://calendly.com/d/mhdm-m9vv/60-min-zoom-mark-bruce
==================================
From: <harold@mastersystems.com.pg>
Subject: RE: Development Update
Date: December 6, 2022 at 7:31:42 PM MST
To: "'Bruce Gilkes'" <bgilkes@altscanada.com>, "'Phillip Kaiwai'" <phil@mastersystems.com.pg>, <andy@mastersystems.com.pg>
Cc: "'Mark Deller'" <mdeller@altscanada.com>
Hi Bruce
Thanks for this …. See my comments below
=============
From: Bruce Gilkes <bgilkes@altscanada.com> 
Sent: Wednesday, 7 December 2022 5:15 AM
To: Harold Richardson <harold@mastersystems.com.pg>; Phillip Kaiwai <phil@mastersystems.com.pg>; andy@mastersystems.com.pg
Cc: Mark Deller <mdeller@altscanada.com>
Subject: Re: Development Update
 
For timing and Phase close out clarification:
 
Phase 1 - (Items 1 & 2, below) will be closed out around the end of this week and this will close out our Phase 1 work for you, Harold.
Phase 2 - (Item 3) will be done around the end of the month and subject to whatever agreement Phil and Mark work out.  There are approximately 3 weeks of work total with both Phase 1 and 2
Phase 3 - (Items 4 & 5, below) will follow on after Christmas.  As per Phase 2, this will be subject to the same agreement with Phil/Mark on development and revenue/sales.
 
This means that, shortly, Howard will be able to upload the JMP file and it will be processed into a .pdf that will have the full plan on page 1, and the individual driver/vehicle trip plans on subsequent pages.  This will be available for download at a particular web address/site.  When the next day is over, an additional file will be placed in the same location that will have the Daily Movement Report comparison.  
 
Around Christmas or before the start of the new year, we will have a separate web app for monitoring where you will be able to see what is going on/alarms for late shipments.
 
After Christmas we would be working on the optimization and dashboard.
 
All the best,
 
Bruce
===================================================================

Conversation opened. 3 messages. All messages read.

Skip to content
Using Gmail with screen readers
2 of 3,638
Fwd: JMP Workflows and Run Sheets
Inbox

=================================================
Javier Jaime
10:04 AM (3 hours ago)
FYI, in POM-PNG they always want it for yesterday, and it is still doable, they are 17 hours ahead. Can you please call me? or let me know when I can call you,

Bruce Gilkes
11:24 AM (1 hour ago)
to Howard, Harold, Christiegayle, andy, phil, Javier

Hi Howard,
They are completing this work and testing this weekend.  Should be good to go by Monday.
LCol (ret’d) Bruce Gilkes
=============================
On Dec 8, 2022, at 1:26 AM, Howard Numan <howard@mastersystems.com.pg> wrote:

Hi Bruce,
I hope this email finds you well.
Would you be able to let us know how soon we could test the JMP features for Importing Workflows and Exporting Run Sheets?
Kind Regards,
Howard Numan
Email: howard@mastersystems.com.pg | Digicel: +67571246556

Bruce Gilkes
11:41 AM (1 hour ago)
to Howard, Javier, Harold, Christiegayle, andy, Phillip, me

Hi Howard,
Can you provide a cloud-based (Google Drive, One Drive, Box, etc.) location where you will upload the JMP?  Please provide access to me, Javier and Dave Walley (emails above)
- When you upload a JMP into this location (please continue the naming convention), we will grab the JMP and create the trip sheets and place them back in the same folder
- At the end of the next day, when the DMR is available for that day, we will compare the JMP and the DMR and also place the comparison back in the same folder with the same naming convention

Please let me know if this makes sense.
All the best,
Bruce
=========================================================================
