<html><!-- Debug and test page for ALTS WordPress plugin in a localhost page -->
<!-- (c)2022 ALTS. Author: David C. Walley -->
 <head>
  <style>
   @media screen and (min-width: 640.001px) {
    .display_if_slim {visibility:hidden;height:0;pointer-events:none}
   }
   @media screen and (max-width: 640px) {
    .display_if_wide {visibility:hidden;height:0;pointer-events:none}
   }
  </style>
 </head>
  <?php // Debug and test - similar code to the following is normally found within a WordPress page
   echo '<body style="overflow:hidden">';
/*DEV*/   include '$_alts_custom_plugin.php';
//*PRO*/  include 'alts_custom_plugin.php';
   echo alts_plans();              //> Analog of a WP shortcode.
   echo alts_sjavascript();        //> Analog of a WP shortcode.
  ?>
 </body>
</html>