// $_alts_custom_plugin.js_php - JavaScript with PHP macros (needs proper .htaccess file). Client-based code for ALTS project.
// (c)2022 ALTS. Author: David C. Walley. All rights reserved.



"use strict";


class classGlobals_ca_davidwalley {

  constructor() {

    /*private*/ this.s_i = 0; // Current count for unique IDs for DOM elements.
    const me = this;

  }

}


classGlobals_ca_davidwalley.ele = function (a) { // Code convenience.
  return document.getElementById(a);
};

classGlobals_ca_davidwalley.bIS = function (a) { // Code convenience for detecting undefined variable and avoiding potential error of typo which will compile.
  return "undefined" !== typeof a;
};

classGlobals_ca_davidwalley.OUT = function (a, b) { // Output to DOM - display a result in a div.
  classGlobals_ca_davidwalley.ele(a).innerHTML = b + "";
};

classGlobals_ca_davidwalley.prototype.nONCE = function () { // Serial counter to ensure unique IDs of created DOM elements.
  this.s_i++;
  return this.s_i;
};


var G = classGlobals_ca_davidwalley;

function g_sDRIVER_PRINTABLE() {
  return "alts_driver_printable";
}


const onClick_Print = function (a_event) {
  console.log("here we are 3");
  let sId = a_event.target.id;
  console.log(sId);
  let iId = sId.split("_")[2];
  let ele = G.ele("alts_printable_" + iId + "");
  let mywindow = window.open("", "PRINT", "height=400,width=600");
  mywindow.document.write("<html><head><title>" + document.title + "</title>");
  mywindow.document.write("</head><body >");
  mywindow.document.write("<h1>" + document.title + "</h1>");
  mywindow.document.write(ele.innerHTML);
  mywindow.document.write("</body></html>");
  mywindow.document.close();
  mywindow.focus();
  mywindow.print();
  mywindow.close();
};


const Go = function () {
  console.log("here we are 20");
  let ele = document.getElementsByClassName("entry-header")[0];
  if (ele) {
    ele.style.display = "none";
  }
  let a = document.getElementsByClassName("alts_print_");
  console.log("here we are 21 " + a.length);
  console.log(JSON.stringify(a));
  for (let i = 0; i < a.length; i++) {
    console.log("here we are 22");
    a[i].addEventListener("click", onClick_Print, false);
  }
};


Go();
console.log("here we are 1");

// End of file.
