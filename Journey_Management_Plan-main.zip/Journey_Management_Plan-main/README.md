# Journey_Management_Plan
Journey Management Plan Web App

Projects
========
* Express Freight Management "Journey Management Planning" Web Application - Phase 1
* Simberi Mine   web app - spreadsheet for the simberi mine

Locations
=========
* Lae
* Port Moresby, Papua New Guinea (POM)
* Simberi Mine, Papua New Guinea
* South Africa
* Calgary

Companies
=========
* ALTS
* Express Freight Management (EFM)
* MST
* Mix Telematics

People
======
* David Walley                                            <davewalley54@gmail.com>

* Javier Jaime                                            <jjaime@altscanada.com>
* LCol (ret’d) Bruce Gilkes Managing Partner ALTS Canada  <bgilkes@altscanada.com>
* Mark Deller                                             <mdeller@altscanada.com>

* Godfrey Willis Operations Department  (Digicel)         <godfrey@mastersystems.com.pg>
* Howard Numan                                            <howard@mastersystems.com.pg>   <mstjmp@gmail.com>
* Christiegayle Masen                                     <christiegayle@mastersystems.com.pg>
* Harold Richardson                                       <Harold@mastersystems.com.pg>
* Jirehbless Suve                                         <jirehbless@mastersystems.com.pg>
* andy                                                    <andy@mastersystems.com.pg>
* Phillip                                                 <phil@mastersystems.com.pg>

* Mark Boulton-Mills                                      <mark@methodexists.com>

Components
==========
JMP Upload, Parse,Download
--------------------------
USER ==> mysite.com/upload = WordPress page                     // https://davidwalley.ca/upload
         Upload plan file.                                      // Uses Wordpress File Upload plugin [wordpress_file_upload]
         --> file in dir setup by plugin                        // https://davidwalley.ca/wp-admin/admin.php?page=wfu_uploaded_files
         Diplay parsed files widget.                            // Use custom plugin aaa_custom [aaa_custom_downloads]
         Download, display and print using browser JavaScript   //

Mix Telematics Realtime Data
----------------------------
CRON ==> mysite.com/cron = WordPress page                       // Once per minute
                         ==> Mix Telematics API                 // https://davidwalley.ca/cron
         mysite.com/cron <==                                    // Use custom plugin aaa_custom [aaa_custom_cron]
         --> file?                                              // TODO save raw response in file system? Same dir as wordpress_file_upload?

WordPress custom code is in aaa_custom.php

Files and Directories
=====================
