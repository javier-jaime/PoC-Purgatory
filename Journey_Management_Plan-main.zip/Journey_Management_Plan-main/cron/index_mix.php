<?php // cron/index.php - PHP server code to test and access MiX Telematics API - Use Filezilla to install on server e.g. davidwalley.ca/cron
// (c)2022 ALTS. Author: David C. Walley


//////////////////////////////////////////////////////////////////////////////////////////////////////////>
//////////////////////////////////////////////////////////////////////////////////////////////////////////# Globals and general purpose routines.

function                                o($a){ echo $a ."\n"; }                                         //# Code convenience.


function                                sId(//////////////////////////////////////////////////////////////# Format a 16 digit hex identifier.
                                        $a_id                                                           //>
){                                      //////////////////////////////////////////////////////////////////>
                            $r_s = substr(   '0000000000000000'.strtoupper( dechex($a_id) )   ,-16   ); //>
return substr($r_s ,0,4).' '.substr($r_s ,4,4).' '.substr($r_s ,8,4).' '.substr($r_s ,12,4);            //>
}//sId////////////////////////////////////////////////////////////////////////////////////////////////////>


function                                sRgbHash(/////////////////////////////////////////////////////////# Create an RGB CSS color based on a hash of the given text, for making it easier for humans to spot duplicates of text.
                                        $a_s                                                            //>
){                                      //////////////////////////////////////////////////////////////////>
                                        $s                      = md5( $a_s );                          //>
                                        $nR     = floor(   255*0.4 + 0.6*hexdec( substr($s ,2,2) )   ); //>
                                        $nB     = floor(   255*0.4 + 0.6*hexdec( substr($s ,0,2) )   ); //>
                                        $nG     = floor(   ( 767 - $nR - $nB )*0.5                   ); //>
 if( 255 < $nG ){ $nG = 255; }                                                                          //>
return '#'. substr( '0'.dechex($nR) ,-2)                                                                //>
          . substr( '0'.dechex($nG) ,-2)                                                                //>
          . substr( '0'.dechex($nB) ,-2)                                                                //>
 ;                                                                                                      //>
}//sRgbHash///////////////////////////////////////////////////////////////////////////////////////////////>


function                                GET(//////////////////////////////////////////////////////////////# Perform network GET call.
                                        $c                                                              //>
,                                       $a_sUrl                                                         //>
,                                       $a_sErr                                                         //> Error message.
){                                      //////////////////////////////////////////////////////////////////>
                                        $r                      = $c->get( $a_sUrl );                   //>
 if( 200 === $r->info->http_code ){                                                          return $r;}//>
 o($a_sErr .") Failed ". $r->info->http_code .".");                                                     //>
exit();                                                                                                 //> Halt execution.
}//GET////////////////////////////////////////////////////////////////////////////////////////////////////>


function                                POST(/////////////////////////////////////////////////////////////# Perform network POST call.
                                        $c                                                              //>
,                                       $a_sUrl                                                         //>
,                                       $a_vData                                                        //>
,                                       $a_sErr                                                         //> Error message.
){                                      //////////////////////////////////////////////////////////////////>
                                        $r              = $c->post( $a_sUrl ,json_encode($a_vData) );   //>
 if( 200 === $r->info->http_code ){                                                          return $r;}//>
 if( 204 === $r->info->http_code ){                                                        return null;}//>
 o($a_sErr .") Failed ". $r->info->http_code .".");                                                     //>
exit();                                                                                                 //> Halt execution.
}//POST///////////////////////////////////////////////////////////////////////////////////////////////////>


//. MiX.Integrate.Api                      https://integrate.za.mixtelematics.com/#api-reference
//. GET    /api/assets/                 group/ {groupId}                                                //> List of assets in organisation, subgroup or site
$sGROUPSaSSETS__id       = "/api/assets/group/";                                                        //> List of assets in organisation, subgroup or site
//. GET    /api/organisationgroups/           details/      {nGroupId}                                  //> Get organisation detail
$sGROUPdETAILS__id = "/api/organisationgroups/details/";                                                //> Get organisation detail.
//. POST   /api/positions/ assets/          latest/{quantity}                                           //> Get the latest position of each asset in a list.
$sPOSITIONSlATEST1 = "/api/positions/assets/latest/1";                                                  //> One item per asset.
//. POST   /api/positions/ assets/          since/{since}                                               //> Get positions since date (maximum 7 days) for each asset in a list
$sPOSITIONSsINCE   = "/api/positions/assets/since/";                                                    //>
//. GET        /version                 [ base url: , api version: v1 ]                                 //>
$sVERSION   = "/version";                                                                               //>


//////////////////////////////////////////////////////////////////////////////////////////////////////////>
//////////////////////////////////////////////////////////////////////////////////////////////////////////> MIX API test exercises.



require __DIR__ .'/vendor/autoload.php';                                                                //> Require the Composer autoload.
                                        $clientName  = "";                                              //> Variables: ???
                                        $sApiUrl     = "https:/"."/integrate.au.mixtelematics.com";     //> let ApiUrl               = "https:/"+"/integrate.au.mixtelematics.com";
                                        $sIdUrl      = "https:/"."/identity.au.mixtelematics.com/core"; //> let IdentityUrl          = "https:/"+"/identity.au.mixtelematics.com" ; //> BaseAddress The Identity Servers base URL
                                        $sIdClient   = "artemis.alts.canada"   ;                        //> let IdentityClientId     = "artemis.alts.canada"                      ; //> ClientId     The Client Id assigned to the application
                                        $sIdSecret   = "CjEVtbaPGVyaZy7i"      ;                        //> let IdentityClientSecret = "CjEVtbaPGVyaZy7i"                         ; //> ClientSecret The Client Secret associated with the Client Id
                                        $sIdUsername = "bgilkes@altscanada.com";                        //> let IdentityUsername     = "bgilkes@altscanada.com"                   ; //> UserName     The user's MiX Fleet Manager username
                                        $sIdPassword = "ALTS2022Telematics"    ;                        //> let IdentityPassword     = "ALTS2022Telematics"                       ; //> Password     The user's MiX Fleet Manager password
                                        $nGroupId    = 6036446169900172433     ;                        //> Done another way below.   let GroupId              = 6036446169900172433; // ??? Hard-coded?                                                                                                      //* GroupId = 6036446169900172433  Group ID for EFM//>
                                        $sScope      = "offline_access MiX.Integrate";                  //> This is required for MiX Integrate.   let IdentityScope = "MiX.Integrate"; //> Scopes       The sScope of the Connection

use Jumbojett\OpenIDConnectClient;                                                                      //> A simple library that allows an application to authenticate a user through the basic OpenID Connect flow. Connect to the OpenID with OpendID-Connect-PHP -- for help: https://github.com/jumbojett/OpenID-Connect-PHP
                                        $oidc                   = new OpenIDConnectClient( $sIdUrl      //> Create the OpenID Connect object
                                                                  ,                        $sIdClient   //>
                                                                  ,                        $sIdSecret   //>
                                                                  );                                    //>
$oidc->providerConfigParam(   array('token_endpoint' => $sIdUrl."/connect/token")   );                  //> Request Client Credentials Token. Set params for the OpenID Client?:   https://github.com/jumbojett/OpenID-Connect-PHP
$oidc->addScope(                                        $sScope                     );                  //> ???Used to specify the scope of the requested authorisation in OAuth. The scope value openid signals a request for OpenID authentication and ID token.   https://connect2id.com/learn/openid-connect
$oidc->setClientName(                                   $clientName                 );                  //>
$oidc->addAuthParam(          array('username'       => $sIdUsername            )   );                  //>
$oidc->addAuthParam(          array('password'       => $sIdPassword            )   );                  //>

                                        $B                      = '<br/>';
                             $r                               = $oidc->requestResourceOwnerToken(true); //> Perform the auth and return the token (to validate check if the access_token property is there and a valid JWT) : Get the bearer token. Request bearer token from: https://identity..mixtelematics.com/core
if( is_null($r) ){ o("Bearer token request ". $sIdUrl ." failed.");                             exit();}//> If there was a problem, then quit.
o( $B."1) token_type: "     .$r->token_type      );                                                     //> Display token type and
o( $B."2) expires_in: "     .$r->expires_in      );                                                     //> its expiry time.
                                        $tokenAccess            = $r->access_token;                     //> Remember the access token.
o( $B."3) Length: "      .strlen(  $tokenAccess ) );                                                    //>
o( $B                                            );                                                     //>
                                        $c   = new RestClient(                                          //> Create RESTClient object -- for help: https://github.com/tcdent/php-restclient
                                                ['base_url'=> $sApiUrl                                  //>
                                                ,'headers' => ['Authorization'=> 'Bearer '.$tokenAccess //>
                                                              ,'Content-Type' => 'application/json'     //>
                                                              ,'Accept'       => 'application/json'     //>
                                                              ]                                         //>
                                               ]);                                                      //>
                                  $r = GET( $c ,$sVERSION                    ,"04")->decode_response(); //>
o( $B."4) Name: "                .$r->Name            );                                                //>
o( $B."5) Version: "             .$r->Version         );                                                //>
                                  $r = GET( $c ,$sGROUPdETAILS__id .$nGroupId,"06")->decode_response(); //> Get organisation detail.
print_r($r);
o( $B."6) Details for GroupId: " .$r->GroupId         );                                                //> The ID of the organisation
o( $B."7) Name: "                .$r->Name            );                                                //>
o( $B."8) GroupType: "           .$r->GroupType       );                                                //> ['DataCentre', 'RsoGroup', 'DealerGroup', 'MultiLevelOrg', 'OrganisationGroup', 'OrganisationSubGroup', 'SiteGroup', 'DefaultSite', 'SecurityGroup', 'NotificationGroup', 'NotificationAssetsGroup', 'NotificationDriversGroup', 'NotificationEventsGroup', 'MobileDeviceAdminCommissioningGroup', 'DriverUserGroup']
o( $B."9) DisplayTimeZone: "     .$r->DisplayTimeZone );                                                //>
                              $assets= GET( $c ,$sGROUPSaSSETS__id .$nGroupId,"10")->decode_response(); //> List of assets in organisation, subgroup or site
o( $B."10) Assets: "  .count( $assets )          );                                                     //>
                                                                                                        //> CREATE LIST OF ASSETS to get in API call:
                                        $whenNow_s              = time();
                                        $assetIds               = array();                              //> List of asset IDs, for getting more info about each asset.
foreach( $assets as $asset ){   array_push( $assetIds ,$asset->AssetId );   }
o( '<br>--------------' );
//print_r( $assetIds );
                                $r    = POST( $c ,'/api/positions/assets/latest/1' ,$assetIds ,"99" );
if( null !== $r ){
                                                                                                        //> RESULT OF HITTING THIS URL - APPENDED TO OUTPUT FILE
//                              $file = fopen('c:\$\ALTS\mix_'. '2022_10_24' .'.csv', 'a')or die("Oops"); //> Opens file in append mode.
                                        $r_s                    = '';
 $r_s .= 'Timestamp'         .','; $r_s .= 'Latitude'              .','; $r_s .= 'Longitude' .',';
 $r_s .= 'DriverId'          .','; $r_s .= 'AssetId'               .','; $r_s .= 'PositionId'.',';
 $r_s .= 'OdometerKilometres'.','; $r_s .= 'AgeOfReadingSeconds'   .','; $r_s .= 'IsAvl'     .',';
 $r_s .= 'Source'            .','; $r_s .= 'Pdop'                  .','; $r_s .= 'Vdop'      .',';
 $r_s .= 'Hdop'              .','; $r_s .= 'NumberOfSatellites'    .','; $r_s .= 'Heading'   .',';
 $r_s .= 'AltitudeMetres'    .','; $r_s .= 'SpeedKilometresPerHour'.',';
 o(             $r_s.'<br/>' );
// fwrite( $file ,$r_s."\n"    );
                                        $aAtLatest              = $r->decode_response();
 o( count($aAtLatest) );
 for( $i = 0; $i < count($aAtLatest); $i++ ){
                                        $ob                     = $aAtLatest[$i];
                                        $r_s                    = '';
  $r_s .= '"'.( isset($ob->Timestamp             ) ?$ob->Timestamp              :'' ).'",';
  $r_s .= '"'.( isset($ob->Latitude              ) ?$ob->Latitude               :'' ).'",';
  $r_s .= '"'.( isset($ob->Longitude             ) ?$ob->Longitude              :'' ).'",';
  $r_s .= '"'.( isset($ob->DriverId              ) ?$ob->DriverId               :'' ).'",';
  $r_s .= '"'.( isset($ob->AssetId               ) ?$ob->AssetId                :'' ).'",';
  $r_s .= '"'.( isset($ob->PositionId            ) ?$ob->PositionId             :'' ).'",';
  $r_s .= '"'.( isset($ob->OdometerKilometres    ) ?$ob->OdometerKilometres     :'' ).'",';

  $r_s .= '"'.( isset($ob->AgeOfReadingSeconds   ) ?$ob->AgeOfReadingSeconds    :'' ).'",';
  $r_s .= '"'.( isset($ob->IsAvl                 ) ?$ob->IsAvl                  :'' ).'",';
  $r_s .= '"'.( isset($ob->Source                ) ?$ob->Source                 :'' ).'",';
  $r_s .= '"'.( isset($ob->Pdop                  ) ?$ob->Pdop                   :'' ).'",';
  $r_s .= '"'.( isset($ob->Vdop                  ) ?$ob->Vdop                   :'' ).'",';
  $r_s .= '"'.( isset($ob->Hdop                  ) ?$ob->Hdop                   :'' ).'",';
  $r_s .= '"'.( isset($ob->NumberOfSatellites    ) ?$ob->NumberOfSatellites     :'' ).'",';
  $r_s .= '"'.( isset($ob->Heading               ) ?$ob->Heading                :'' ).'",';
  $r_s .= '"'.( isset($ob->AltitudeMetres        ) ?$ob->AltitudeMetres         :'' ).'",';
  $r_s .= '"'.( isset($ob->SpeedKilometresPerHour) ?$ob->SpeedKilometresPerHour :'' ).'",';
  o(             $r_s.'<br/>' );
//  fwrite( $file ,$r_s."\n"    );
}}//for $i//if
//fclose($file);


//End of file.