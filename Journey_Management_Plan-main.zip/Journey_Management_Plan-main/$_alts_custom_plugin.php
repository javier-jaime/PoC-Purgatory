<?php
/*
Plugin Name: ALTS custom plugin.
Plugin URI:  https://wordpress.org/plugins/
Description: Custom code for WordPress for ALTS
Version:     0.0.1
Author:      David Walley
Author URI:  https://davidwalley.ca
*/
// Server-side PHP code for ALTS WordPress site.
// (c)2022 ALTS. Author: David C. Walley
// In WordPress:                                                                                        //>
//   Using File Manager, Drag and drop a copy of this file in wp-content/plugins/alts_custom_plugin     //>
//                       Also, do the same with alts_custom_plugin.js                                   //>
//   Dashboard > Appearance > Customize > Additional CSS:                                               //>
//     @media screen and (min-width: 640.001px) {                                                       //> For screens greater than 640 pixels wide
//      .display_if_slim {display:none}                                                                 //> For screens greater than 640 pixels wide, Use this class to make div for mobile disappear.
//     }                                                                                                //>
//     @media screen and (max-width: 640px) {                                                           //> When the browser window is 640px wide or less:
//      .display_if_wide {display:none}                                                                 //> When the browser window is 640px wide or less, use this class to make div for desktop disappear
//     }                                                                                                //>
// The following PHP coded plugin is executed by putting a short-code (or a few) on a page. e.g. [alts_product_table]. 
// Anything echoed becomes part of the HTML page source.
// Among other things, this code includes JavaScript.

/*DEV*/  function                       s($a){ return '<!-- '. $a .' -->'; }//////////////////////////////> DEBUG - labels for closing tags.
//*PRO*/ function                       s($a){ return ''                 ; }//////////////////////////////> No labels for closing tags in production code.


function                                g_sSiteImages(////////////////////////////////////////////////////# Get the URL to get an image for this site (WordPress or localhost).
){                                      //////////////////////////////////////////////////////////////////>
                                        $s             = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"]; //> Get the URL used to initiate this code.
 $s = substr( $s ,0 ,strrpos($s,'/') );                                                                 //> Trim away anything after the lalts slash.
 /*DEV*/  return 'http://' . $s .'/images/'            ;                                                //> During localhost development.
 //*PRO*/ //return 'https://'. $s .'/wp-content/uploads/';                                              //> Staging site. ??? Has this been tested?
 //*PRO*/   return get_home_url() .'/wp-content/uploads/';                                              //> Production version.
}//g_sSiteImages//////////////////////////////////////////////////////////////////////////////////////////>


/*DEV*/  include '$_shared.js_php';                                                                     //> Shared code between JavaScript client and PHP server. Mostly constants as functions, which work in either language.
//*PRO*/ include 'shared.js_php';                                                                       //>
include 'SimpleXLSX.php';                                                                               //> Read and parse Excel files. https://github.com/shuchkin/simplexlsx/blob/maltser/src/SimpleXLSX.php
use                                     Shuchkin\SimpleXLSX;                                            //>


function                                g_sTIME(//////////////////////////////////////////////////////////# Time of day
                                        $a                                                              //>
){                                      //////////////////////////////////////////////////////////////////>
                                        $when_s                 = strtotime( $a .' GMT');               //>
return date( 'H:i' ,$when_s );                                                                          //>
}//g_sTIME////////////////////////////////////////////////////////////////////////////////////////////////>


function                                g_sTOOK(//////////////////////////////////////////////////////////>
                                        $a_took_s                                                       //>
){                                      //////////////////////////////////////////////////////////////////>
                                        $nMinutes               = floor( $a_took_s/60 + 0.5 );          //>
 if( $nMinutes <= 60 ){                                                            return $nMinutes.'';}//>
                                        $nHours                 = floor( $nMinutes/60 );                //>
 $nMinutes -= 60*$nHours;                                                                               //>
return $nHours .':'. substr( ''.(1000 + $nMinutes) ,-2 );                                               //>
}//g_sTOOK////////////////////////////////////////////////////////////////////////////////////////////////>


function                                g_nLOCALtIMEzONE_s(){   return 10*3600; }                       //> Local timezone - 10 hours ahead of GMT in Port Moresby.
function                                g_sTOPbUTTONcSS(){      return                                  //>
                                          'display'                     .':inline-block'                //> BUTTON STYLES:
                                        .';background-color'            .':#88FF88'                     //>
                                        .';border'                      .':1px solid #000000'           //>
                                        .';cursor'                      .':pointer'                     //>
                                        .';padding'                     .':0.1em'               ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sTOPlABELcSS(){       return                                  //>
                                          'display'                     .':inline-block'                //> HEADER INFO ABOVE TABLE:
                                        .';font-family'                 .':sans-serif'                  //>
                                        .';font-size'                   .':0.8em'                       //>
                                        .';text-align'                  .':right'                       //>
                                        .';width'                       .':20em'                ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sTABLEcSS(){          return                                  //>
                                          'border'                      .':1px solid #000000'           //> Outside border.
                                        .';border-collapse'             .':collapse'                    //>
                                        .';font-size'                   .':9pt'                         //>
                                        .';width'                       .':99%'                         //> TABLE STYLES:
                                        .';font-family'                 .':sans-serif'          ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sHEADrOWcSS(){        return                                  //>
                                          'background-color'            .':#F8F8F8'                     //>
                                        .';font-size'                   .':0.6em'                       //>
                                        .';font-weight'                 .':bold'                        //>
                                        .';-webkit-print-color-adjust'  .':exact'               ;       //> Fix for Chrome not printing color.
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sPLANrOWcSS(){        return                                  //>
                                          'background-color'            .':#F8F8F8'                     //>
                                        .';-webkit-print-color-adjust'  .':exact'                       //> Fix for Chrome not printing color.
                                        .';border-top'                  .':2px solid #000000'           //>
                                        .';font-size'                   .':0.9em'               ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sACTUALrOWcSS(){      return                                  //>
                                          'background-color'            .':#FFFFFF'                     //>
                                        .';-webkit-print-color-adjust'  .':exact'                       //> Fix for Chrome not printing color.
                                        .';font-size'                   .':0.9em'               ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sVARIANCErOWcSS(){    return                                  //>
                                          'background-color'            .':#FFEEEE'                     //>
                                        .';-webkit-print-color-adjust'  .':exact'                       //> Fix for Chrome not printing color.
                                        .';font-size'                   .':0.9em'               ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sHEADcELLcSS(){       return                                  //>
                                          'border'                      .':1px solid #AAAAAA'           //>
                                        .';padding'                     .':0.3em'                       //>
                                        .';text-align'                  .':center'              ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sCELLcSS(){           return                                  //>
                                          'border'                      .':1px solid #AAAAAA'           //>
                                        .';padding'                     .':0.3em'                       //>
                                        .';text-align'                  .':center'              ;       //>
                                        }/////////////////////////////////////////////////////////////////>
function                                g_sCELL0cSS(){          return                                  //>
                                          'border'                      .':1px solid #AAAAAA'           //>
                                        .';padding'                     .':0.3em'                       //>
                                        .';text-align'                  .':right'               ;       //>
                                        }/////////////////////////////////////////////////////////////////>

function                                g_sDATElOCALfORM(){ return 'd-m-Y'; }                           //> Preferred local date format. ' H:i:s';


function                                sDriverReport(////////////////////////////////////////////////////#
                                        $a_sDate                                                        //>
,                                       $a_iPrintDiv                                                    //>
,                                       $a_sTruck                                                       //>
,                                       $a_sMid                                                         //>
,                                       $a_asPlaces                                                     //>
,                                       $a_nSum6                                                        //>
,                                       $a_nSum11                                                       //>
){                                      //////////////////////////////////////////////////////////////////> Report ?
return                                                                                                  //>
   '<div style="margin:0 0 0 1em">'                                                                     //> Indent the detail level.
  . '<details>'                                                                                         //>
  .  '<summary>'. $a_sTruck .'</summary>'                                                               //>
  .  '<div class="'. 'alts_print_'                  .'"'                                                //> Print button...
  .  ' id="'.        'alts_print_'.    $a_iPrintDiv .'"'                                                //>
  .  ' style="'. g_sTOPbUTTONcSS()                                                                      //>
  .  '">'. "Print"                                                                                      //>
  .  '</div>'                                                                                           //>
  .  '<div id="'.    'alts_printable_'.$a_iPrintDiv .'">'                                               //>
  .   '<div style="'.  g_sTOPlABELcSS().'">'."Truck"                                    .': </div> '.                         $a_sTruck     .'<br/>'//> e.g. EFM 33 POM - CAMC Flat Top Tandem Axle 18 Tonne (BGP 247) GFI
  .   '<div style="'.  g_sTOPlABELcSS().'">'."Date"                                     .': </div> '.                         $a_sDate      .'<br/>'//>
//.   '<div style="'.  g_sTOPlABELcSS().'">'."File"                                     .': </div> '.$sFile                                 .'<br/>'//>
  .   '<div style="'.  g_sTOPlABELcSS().'">'."Customers"                                .': </div> '.implode( ', ',array_keys($a_asPlaces) ).'<br/>'//> e.g. Avenell Engineering Systems, Ealts West/Agility Warehouse
  .   '<div style="'.  g_sTOPlABELcSS().'">'."Total number of unique customers to visit".': </div> '.count(                   $a_asPlaces)  .'<br/>'//>
//.   '<div style="'.  g_sTOPlABELcSS().'">'."No. of Planned Trips"                     .': </div> '."TODO"                                 .'<br/>'//>
  .   '<div style="'.  g_sTOPlABELcSS().'">'."Total number of planned trips"            .': </div> '."TODO"                                 .'<br/>'//> What is difference?
//.   '<div style="'.  g_sTOPlABELcSS().'">'."No. of Planned Loads"                     .': </div> '."TODO"                                 .'<br/>'//>
  .   '<div style="'.  g_sTOPlABELcSS().'">'."Total number of planned loads"            .': </div> '."TODO"                                 .'<br/>'//>
  .   '<table style="'.g_sTABLEcSS(   ).'">'                                                            //>
  .    '<tr style="'.  g_sHEADrOWcSS( ).'">'                                                            //>
  .     '<td style="'. g_sHEADcELLcSS().'">'."Load #"           .'</td>'                                //> Load #
  .     '<td style="'. g_sHEADcELLcSS().'">'."Detail"           .'</td>'                                //> Detail
  .     '<td style="'. g_sHEADcELLcSS().'">'."Driver"           .'</td>'                                //> Driver Name
  .     '<td style="'. g_sHEADcELLcSS().'">'."Departure Time"   .'</td>'                                //> Departure Time
  .     '<td style="'. g_sHEADcELLcSS().'">'."Depart From"      .'</td>'                                //> Depart Location
  .     '<td style="'. g_sHEADcELLcSS().'">'."Driving Time"     .'</td>'                                //> Travel Time
//.     '<td style="'. g_sHEADcELLcSS().'">'."Distance"         .'</td>'                                //> ?
  .     '<td style="'. g_sHEADcELLcSS().'">'."Load Type"        .'</td>'                                //> Load Type
  .     '<td style="'. g_sHEADcELLcSS().'">'."Load"             .'</td>'                                //> Load
  .     '<td style="'. g_sHEADcELLcSS().'">'."Arrival Time"     .'</td>'                                //> Arrival Time
  .     '<td style="'. g_sHEADcELLcSS().'">'."Arrive At"        .'</td>'                                //> Arrive Location
//.     '<td style="'. g_sHEADcELLcSS().'">'."Next Departure"   .'</td>'                                //> ?
  .     '<td style="'. g_sHEADcELLcSS().'">'."Time at Location" .'</td>'                                //> Load/Off-load Time
  .    '</tr>'                                                                                          //>
  .     $a_sMid                                                                                         //>
  .    '<tr>'                                                                                           //>
  .     '<td style="text-align:center">'."TOTALS"          .'</td>'.'<td></td>'.'<td></td>'.'<td></td>'.'<td></td>'//>
  .     '<td style="text-align:center">'.g_sTOOK($a_nSum6 ).'</td>'.'<td></td>'.'<td></td>'.'<td></td>'.'<td></td>'//>
  .     '<td style="text-align:center">'.g_sTOOK($a_nSum11).'</td>'                                     //>
  .    '</tr>'                                                                                          //>
  .   '</table>'                                                                                        //>
  .  '</div>'//alts_printable_                                                                          //>
  .  '<div style="page-break-before:always"></div>'                                                     //> ???NOT WORKING? Chrome problem?
  .  '<br/><br/>'                                                                                       //>
  . '</details>'                                                                                        //>
  .'</div>' ."\n";                                                                                      //>
}//sDriverReport//////////////////////////////////////////////////////////////////////////////////////////>


function                                avReadParse(//////////////////////////////////////////////////////# Read Excel format file, and parse into a table of cells.
                                        $a_sFile                                                        //>
){                                      //////////////////////////////////////////////////////////////////> Report FALSE and an error message, or an Excel file object and the date from the file name.
                                        $sDate                  =                                       //>
           implode( '_' ,explode(' ' ,$a_sFile) );                                                      //>
 $sDate  = implode( '_' ,explode('-' ,$sDate) );                                                        //>
 $sDate  = implode( '_' ,explode('.' ,$sDate) );                                                        //>
 $asDate =               explode('_' ,$sDate)  ;                                                        //>
 for( $i = 0; $i < count($asDate) - 2; $i++ ){                                                          //>
  if(   is_numeric( $asDate[$i    ] )                                                                   //>
   &&   is_numeric( $asDate[$i + 1] )                                                                   //>
    &&  is_numeric( $asDate[$i + 2] )                                                                   //>
  ){                                                                                                    //>
                                      $r_xlsx = SimpleXLSX::parse('./wp-content/uploads/alts/'.$a_sFile);//>
   if( FALSE === $r_xlsx ){                                                                             //>
return [ FALSE                                                                                          //>
       ,"Parsing error: ". SimpleXLSX::parseError()                                                     //>
        .' >>'. file_get_contents('./wp-content/uploads/alts/'.$a_sFile) .'<<'                          //>
       ];                                                                                               //>
   }//if                                                                                                //>
                                        $when_s                 = strtotime( $asDate[$i + 2]            //>
                                                                  .'-'.      $asDate[$i + 1]            //>
                                                                  .'-'.      $asDate[$i    ]            //>
                                                                  .' GMT'                               //>
                                                                  ) - g_nLOCALtIMEzONE_s();             //>
return [   $r_xlsx ,date( g_sDATElOCALfORM() ,$when_s + g_nLOCALtIMEzONE_s() ) .'('. $when_s .')'   ];  //> Success.
 }}//if//for $i                                                                                         //>
return[FALSE ,"Bad file name: ".$a_sFile];                                                              //>
}//avReadParse////////////////////////////////////////////////////////////////////////////////////////////>


if( function_exists('add_shortcode') ){                                                                 //> If running within WordPress...
                     add_shortcode(    'alts_plans' ,                                                   //> Define shortcode to insert into WP page: [...]
                                       'alts_plans'); }                                                 //>
function                                alts_plans(///////////////////////////////////////////////////////# HTML code for tabular driver plan.
){                                      //////////////////////////////////////////////////////////////////>
                                        $iPrintDiv             = 0;                                     //>
                                        $files                 = scandir('./wp-content/uploads/alts/'); //> Set base directory in WP|dashboard|Settings|Wordpress File Upload Control Panel
                                        $r_s                   =                                        //>
                                         '<div style="'                                                 //>
                                        .  'all'                .':revert'                              //>
                                        . ';background-color'   .':#F8F8F8'                             //> Gray background like WordPress.
                                        . ';overflow-x'         .':auto'                                //>
                                        . ';overflow-y'         .':auto'                                //>
                                        . ';width'              .':100%'                                //>
                                        . ';height'             .':100%'                                //>
                                        .'">';                                                          //>
                                        $sFileEnd               = '';                                   //>
 foreach( $files as $sFile ){   if( $sFile == '.'   ||   $sFile == '..' ){                    continue;}//> For each file in the list...
                                        $av                     = avReadParse( $sFile );                //>
                                        $xlsx                   = $av[0];                               //>
  if( FALSE === $xlsx ){ $r_s .= $av[1];                                                      continue;}//>
                                        $sDate                  = $av[1];                               //>
  $r_s .= $sFileEnd.'<details><summary>'. $sDate." &nbsp; &nbsp; &nbsp; &nbsp; ".$sFile .'</summary>';  //>
  $sFileEnd =       '</details>';                                                                       //>
                                        $sMid                   = '';                                   //>
                                        $asPlaces               = array();                              //>
                                        $sTruck                 = '';                                   //>
                                        $nSum6                  = 0;                                    //>
                                        $nSum11                 = 0;                                    //>
  foreach( $xlsx->rows() as $asCells ){                                                                 //>
   if( count($asCells) < 12 ){ $r_s .= "Bad file format";                                        break;}//>
   if( ''          === $asCells[0] ){                                                         continue;}//> Ignore empty rows.
   if( 'Workflow'  === $asCells[0] ){                                                         continue;}//> Ignore header rows.

   if( $sTruck !== $asCells[1] ){                                                                       //> If there is a new truck, then...
    if( '' !== $sMid ){                                                                                 //>
     $r_s .= sDriverReport( $sDate ,$iPrintDiv ,$sTruck ,$sMid ,$asPlaces ,$nSum6 ,$nSum11 );           //> Output previous driver's sections.
     $iPrintDiv++; $sMid = ''; $asPlaces = array(); $nSum6 = 0; $nSum11 = 0;                            //>
    }//if                                                                                               //>
    $sTruck = $asCells[1];                                                                              //> Remember new truck
   }//if                                                                                                //>
// 1    |PLAN           |Billy Madoni|8:30 AM  |Avenell Engineering Systems|0:30:00     |              |Empty Container|1x 20'ft MT|9:00 AM     |East West/Agility Warehouse|10:00 AM |1:00:00//>
//      |ACTUAL TRACKING|            |         |                           |            |              |               |           |            |                           |         |//>
//      |VARIANCE       |            |         |                           |            |              |               |           |            |                           |         |//>
// 2    |PLAN           |Billy Madoni|10:00 AM |East West/Agility Warehouse|0:30:00     |              |               |           |10:30 AM    |Avenell Engineering Systems|11:00 AM |0:30:00//>
//      |ACTUAL TRACKING|            |         |                           |            |              |               |           |            |                           |         |//>
//      |VARIANCE       |            |         |                           |            |              |               |           |            |                           |         |//>
// ??? TODO total line.                                                                                 //>
//      |TOTAL:         |            |         |                           |2:30:00     |           0.0|                                                                              |4:00:00//>
   $asPlaces[ $asCells[ 5] ] = 1;                                                                       //> "Depart Location"
   $asPlaces[ $asCells[10] ] = 1;                                                                       //> "Arrive Location"
                                        $took6_s                = strtotime($asCells[ 6].' GMT');       //>
                                        $took11_s               = strtotime($asCells[11].' GMT');       //>

   $sMid .= '<tr style="'. g_sPLANrOWcSS().'">'                                                         //>
          .  '<td style="'.g_sCELLcSS( )  .'" rowspan="3">'.$asCells[ 3]                      .'</td>'  //> "Load #"
          .  '<td style="'.g_sCELL0cSS()  .'">'.                                    "PLAN"    .'</td>'  //>
          .  '<td style="'.g_sCELLcSS( )  .'">'.            $asCells[ 2]                      .'</td>'  //> "Driver Name"
          .  '<td style="'.g_sCELLcSS( )  .'">'. g_sTIME(   $asCells[ 4] )                    .'</td>'  //> "Departure Time"     -> UNIX Timestamp?
          .  '<td style="'.g_sCELLcSS( )  .'">'.            $asCells[ 5]                      .'</td>'  //> "Depart Location"
          .  '<td style="'.g_sCELLcSS( )  .'">'. g_sTOOK(   $took6_s     )                    .'</td>'  //> "Travel Time"        -> seconds?
          .  '<td style="'.g_sCELLcSS( )  .'">'.            $asCells[ 7]                      .'</td>'  //> "Load Type"
          .  '<td style="'.g_sCELLcSS( )  .'">'.            $asCells[ 8]                      .'</td>'  //> "Load"
          .  '<td style="'.g_sCELLcSS( )  .'">'. g_sTIME(   $asCells[ 9] )                    .'</td>'  //> "Arrival Time"       -> UNIX Timestamp?
          .  '<td style="'.g_sCELLcSS( )  .'">'.            $asCells[10]                      .'</td>'  //> "Arrive Location"
          .  '<td style="'.g_sCELLcSS( )  .'">'. g_sTOOK(   $took11_s    )                    .'</td>'  //> "Load/Off-load Time" -> seconds
          . '</tr>';                                                                                    //>
   $nSum6  += $took6_s ;                                                                                //>
   $nSum11 += $took11_s;                                                                                //>
                                        $C                    = '<td style="'. g_sCELLcSS() .'"></td>'; //>
   $sMid .= '<tr style="'.g_sACTUALrOWcSS(  ).'">'.'<td style="'.g_sCELL0cSS().'">'."ACTUAL"  .'</td>'.$C.$C.$C.$C.$C.$C.$C.$C.$C.'</tr>'//>
          . '<tr style="'.g_sVARIANCErOWcSS().'">'.'<td style="'.g_sCELL0cSS().'">'."VARIANCE".'</td>'.$C.$C.$C.$C.$C.$C.$C.$C.$C.'</tr>';//>
  }//foreach row                                                                                        //>
  $r_s .= sDriverReport( $sDate ,$iPrintDiv ,$sTruck ,$sMid ,$asPlaces ,$nSum6 ,$nSum11 );              //> Output previous driver's sections.
 }//foreach sFile                                                                                       //>
 $r_s .= $sFileEnd;                                                                                     //>
return $r_s .'</div>'; // '</iframe>';                                                                  //>
}//alts_plans/////////////////////////////////////////////////////////////////////////////////////////////>


if( !function_exists(                  'plugin_dir_path') ){                                            //> For testing outside of WordPress...
 function                               plugin_dir_path($a){return '.';}                                //>
}//if                                                                                                   //>


if( function_exists('add_shortcode') ){                                                                 //> If running within WordPress...
                     add_shortcode(    'alts_sjavascript',                                              //> Define shortcode to insert into WP page: [...]
                                       'alts_sjavascript'); }                                           //>
function                                alts_sjavascript(/////////////////////////////////////////////////>
){                                      //////////////////////////////////////////////////////////////////>
return '<script>'                                                                                       //>
//return '<script src="'.    plugin_dir_path(__FILE__).'/alts_custom_plugin.js' .'">'                   //>
//return '<script src="'.   'alts_custom_plugin.js'   .'">'                                             //>
     .  file_get_contents( plugin_dir_path(__FILE__).'/alts_custom_plugin.js' )                         //>
     . '</script>';                                                                                     //>
}//alts_sjavascript///////////////////////////////////////////////////////////////////////////////////////>


//. // Following CRON on WordPress server is not working well on GoDaddy. Easier to use CRON service such as https://cron-job.org//>
//. require_once( plugin_dir_path(__FILE__) .'../action-scheduler/action-scheduler.php' );              //>
//.                                                                                                     //>
//. //add_action(        'alts_cron_action' ,'alts_cron_go' );                                          //>
//.                                                                                                     //>
//. if( function_exists('add_shortcode') ){                                                             //> If running within WordPress...
//.                      add_shortcode(    'alts_cron_go',                                              //> Define shortcode to insert into WP page: [...]
//.                                        'alts_cron_go'); }                                           //>
//. function                                alts_cron_go(/////////////////////////////////////////////////> A callback to run when the 'alts_cron_action' scheduled action is run.
//. ){                                      //////////////////////////////////////////////////////////////>
//.                                         $file       = fopen('./wp-content/uploads/alts/cron.txt' ,'a');//>
//.  if( FALSE === $file ){                                                                         return;}//>
//.  fwrite($file, time()."\n");                                                                        //>
//.  fclose($file);                                                                                     //>
//. }//alts_cron_go///////////////////////////////////////////////////////////////////////////////////////>


//. add_action( 'init' ,                   'alts_cron_init' );                                          //>
//. function                                alts_cron_init(///////////////////////////////////////////////> Schedule an action with the hook 'alts_cron_action' to run at midnight each day so that our callback is run then.
//. ){                                      //////////////////////////////////////////////////////////////>
//.  //alts_cron_go(); // DEBUG                                                                         //>
//.  if( as_has_scheduled_action('alts_cron_action') ){                                             return;}//> If already done, then quit.
//.  as_schedule_recurring_action(                                                                      //> Schedule a recurring action
//.   time() + 60                                                                                       //> int    $timestamp                 When the first instance of the job will run.
//.  ,60                                                                                                //> int    $interval_in_seconds       How long to wait between runs.
//.  ,                           'alts_cron_action'                                                     //> string $hook                      The hook to trigger.
//.  ,array()                                                                                           //> array  $args                      Arguments to pass when the hook triggers.
//.  ,''                                                                                                //> string $group                     The group to assign this job to.
//.  ,true                                                                                              //> bool   $unique                    Whether the action should be unique.
//.  );                                                                                                 //> return int                        The action ID.
//. }//alts_cron_init/////////////////////////////////////////////////////////////////////////////////////>


//End of file.