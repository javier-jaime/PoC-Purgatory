rem $_Go.bat - Bodge tool chain automated steps for Closure Compiling and prettifying popularvinylplank code.
rem (c)2022 David C. Walley.

echo ------------- ALTS
@echo off

GOTO :Go1
rem Redirect xampp for local development outside of usual location on disk.
rem I’ve got a folder named alts_custom_plugin and I want to redirect to it from htdocs\alts.
rem Command will only work properly if you run it from an elevated command prompt.
rem Source folders cannot exist ahead of time. MKLINK creates the (virtual) source folder (shortcut) for you. 
rem       source?              target?                                              
mklink /J C:\xampp\htdocs\alts C:\$\Consult_ALTS\Journey_Management_Plan\alts_custom_plugin

        GOTO :End & rem ========================================>

:Go1
set ROOT=C:\$\Consult_ALTS\Journey_Management_Plan\&                                                      rem Root directory of project.
call C:\xampp\htdocs\SHARED\$_Go_Setup.bat                                                              & rem Set some bat variables, common to several scripts like this one.
echo ---Version: %VER%                                                                                  & rem Inform user of version number (based on time).
cd %ROOT%                                                                                               & rem Start in project root directory.

rem FILE NAMES AND PREFIXES:
rem $_             Money code - actual, in-house source of everything including prettified 'source' code, documentation, obfuscated code, test code, whatever you want. May or may not be specific just to you, but is in the repo (code repository).
rem manifest.json  Generated with PHP, but File name cannot be changed.
rem m_             Macros processed (PHP tags executed).
rem n_             Macros processed, production lines uncommented.
rem o_             Compiled with Google Closure Compiler.
rem p_             Prettified 'source' code.
rem q_             Restored blank lines and comments (done this way because prettier.js, which we are using, makes a mess trying to associate comments with code lines. We want an absolutely consistent relationship between the AST (Abstract Syntax Tree built when interpreter parses JavaScript) and the text in source code files, which prettier.js comes close to achieving, but drops the ball with comments and new-lines.)
rem t_             Tidied file.
rem Z_             Temporary intermediate files, sometimes they are just for DEBUG.

rem echo f | xcopy .\$_shared.js_php .\alts_custom_plugin\shared.js_php /Y /D
rem echo f | xcopy .\$_index.php     .\alts_custom_plugin\index.php     /Y /D

call %TIDY%                    .\$_alts_custom_plugin.php                                               & rem Immediate reformat of money code. Over-write original.
call %TIDY%                    .\$_alts_custom_plugin.js_php                                            & rem Immediate reformat of money code. Over-write original.
call %TIDY%                    .\$_shared.js_php                                                        & rem Immediate reformat of money code. Over-write original.

echo --- Prettify and compile main JS money code
rem  Command  Version  Money Code
%FIXER% "PRO" %VER% .\$_shared.js_php                                         .\alts_custom_plugin\shared.js_php           & rem
%FIXER% "PRO" %VER% $_index.php                                               .\alts_custom_plugin\index.php               & rem
%FIXER% "PRO" %VER% .\$_alts_custom_plugin.php                                .\alts_custom_plugin\alts_custom_plugin.php  & rem DEBUG intermediate step - convert to PROduction code (replacing DEV PRO and V macros), after PHP macro expansion and before prettification, without prettier preparation option.
%PHP%               .\$_alts_custom_plugin.js_php > .\_m.js                                                                & rem Run PHP to rewrite PHP macros within the JavaScript code. (not done automatically, unfortunately).
%FIXER% "PRO" %VER%                                 .\_m.js .\_Z.js                                                        & rem DEBUG intermediate step - convert to PROduction code (replacing DEV PRO and V macros), after PHP macro expansion and before prettification, without prettier preparation option.
%FIXER% "PRETTY" %VER%                                      .\_Z.js .\_p.js > .\alts_custom_plugin\alts_custom_plugin.js   & rem Prettify, plus handle newlines and comments. This is generated 'source' code for repo.

        GOTO :End & rem ========================================>

del .\Z_*.*

:End